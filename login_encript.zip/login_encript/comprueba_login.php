<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
<meta http-equiv="Content-Type" content="text/html: charset=utf-8"/>
<title> DCOMUENTO SIN TITULO </title>
<link rel="stylesheet" types="text/css" href="css_login/css_registro.css">
    </head>
    
    <body> 


<?php
        
        $con = new mysqli("localhost", "root", "", "loginval");
        
        if ($con->connect_errno){
            
            echo "No hay conexion: (" . $con->connect_errno . " ) " . $cont->connect_errno;
            
            
        }
            
            $usu= $_POST['login'];
            $pas= $_POST['password'];
            
            if (isset($_POST['registrar'])){
                
                $pass_fuerte = password_hash($pas, PASSWORD_DEFAULT);
                $query_registrar = "INSERT INTO usuarios(usuario, contraseña) VALUES ('$usu', '$pass_fuerte')"; 
             
                if (mysqli_query($con, $query_registrar)){
                    
                    echo "Usuario registrado correctamente: $usu";
                    
                    
                }else{
                    
                    echo "El usuario no fue insentado, ERROR: , $query_registrar. <br> ". mysql_error($con);
                    
                }
                
            }
            
            
            if(isset($_POST['btn_login'])){
                
                $query_usuario = mysqli_query($con, "SELECT * FROM usuarios WHERE usuario = '$usu'");
                
                $nr = mysqli_num_rows($query_usuario);
                
                $buscarpass = mysqli_fetch_array($query_usuario);
                
                if(($nr==1) && (password_verify($pas, $buscarpass['contraseña']))){
                    
                    echo "Bienvenido: $usu";
                    
                }else{
                    echo "Contraseña incorrecta";
                }
                
            }
            
            
            ?>
    </body>
</html>