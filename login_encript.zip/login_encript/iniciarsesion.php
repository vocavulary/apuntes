<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>iniciar sesion</title>
<link rel="stylesheet" types="text/css" href="css_login/css_registro.css">
</head>

    <body>
        <center>
    <h1> Iniciar sesión</h1>

<form action="comprueba_login.php" method="post">

<table>
<tr style="">
<td class="izq">
Login:</td><td class="der"><input type="text" name="login"></td></tr>
<tr><td class="izq">
Password:</td><td class="der"><input type="password" name="password"></td></tr>

<tr><td colspan="2"><input type="submit" name="btn_login" value="LOGIN"></td> </tr>
<tr><td><a href="registrarse.php">Registarse</a></td></tr>
</table>




</form>
</center>
</body>
</html>
